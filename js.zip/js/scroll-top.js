// JavaScript Document

$(document).ready(function() {
										$().UItoTop({ easingType: 'easeOutQuart' });
									});