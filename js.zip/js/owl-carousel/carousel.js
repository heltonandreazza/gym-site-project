// JavaScript Document

 $(function() {
            $('.carousel').carousel({
                interval: 3000,
                pause: "false"
            });
        });