// JavaScript Document

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
