// JavaScript Document
'use strict';
$('.counter').countUp();