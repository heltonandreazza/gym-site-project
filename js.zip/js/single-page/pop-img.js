// JavaScript Document

$(function() {
		   'use strict';
			$('.pop-img').Chocolat();
		});