// JavaScript Document
'use strict';
 new WOW().init();