// JavaScript Document

    $('.carousel').carousel({
        interval: 2500 //changes the speed
    })