// JavaScript Document
$(document).ready(function() {
    $(".link-1").click(function() {
        $(".mobile-div-2").removeClass("in");

    });

    $(".link-2").click(function() {
        $(".mobile-div-1").removeClass("in");
    });

    $(".navbar-toggle").click(function() {
        $(".mobile-div-2").removeClass("in");
        $(".mobile-div-1").removeClass("in");

    });



});