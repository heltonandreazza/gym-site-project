// JavaScript Document
$('#myCarousel').carousel({
    interval: 3000,
 	pause: "false"
});

